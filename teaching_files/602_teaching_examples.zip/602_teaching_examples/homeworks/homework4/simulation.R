mc<-function(r,p){
  library(sandwich)
  set.seed(1)
  M=500
  N=1000
  data<-data.frame(
    x=arima.sim(list(ar=r),N)
  )
  results<-data.frame(
    b1_hat=rep(NA,M),
    se_OLS=rep(NA,M),
    se_NW=rep(NA,M),
    sd=rep(NA,M),
    confidence=rep(NA,M),
    bias=rep(NA,M),
    rho=rep(p,M),
    pi=rep(r,M)
  )
  for (m in 1:M) {
    e<-arima.sim(list(ar=p),N)
    for (i in 1:N) {
      data$y[i]<-1+2*data$x[i]+e[i]
    }
    results[m,1]<-summary(lm(y~x,data))$coefficients[2]
    results[m,2]<-summary(lm(y~x,data))$coefficients[4]
    results[m,3]<-sqrt(diag(NeweyWest(lm(y~x,data),lag=(N^(1/4)))))[2]
  }
  results[,4]<-sqrt(sum((results$b1_hat-mean(results$b1_hat))^2)/length(results$b1_hat))
  results[,5]<-results$sd/mean(results$se_OLS)
  results[,6]<-mean(results$b1_hat)-2
  return(results)
}
mcdata<-rbind(
  mc(-0.5,-0.99),mc(-0.5,-0.75),mc(-0.5,-0.5),mc(-0.5,-0.25),mc(-0.5,0),
  mc(-0.5,0.99),mc(-0.5,0.75),mc(-0.5,0.5),mc(-0.5,0.25),mc(0.5,-0.99),
  mc(0.5,-0.75),mc(0.5,-0.5),mc(0.5,-0.25),mc(0.5,0.99),mc(0.5,0.75),
  mc(0.5,0.5),mc(0.5,0.25),mc(0.5,0)
)
mcdata %>%
  filter(pi=="-0.5") %>%
  ggplot(.,aes(x=rho,y=se_OLS))+geom_point()+geom_line(aes(x=rho,y=sd))
mcdata %>%
  filter(pi=="0.5") %>%
  ggplot(.,aes(x=rho,y=se_OLS))+geom_point()+geom_line(aes(x=rho,y=sd))