M <- 100;N=1000;
data <- data.frame(x = seq(-3, 3, length.out = N));
data$y0 <- 1 + 2 * data$x; rho <- seq(-0.99, 0.99, length.out = 21);
se <- sapply(rho, \(p) {   se <- replicate(M, {     data$y <- data$y0 + arima.sim(list(ar = p), N);
coefficients(lm(y ~ x, data))["x"]   });
sd(se) }); plot(rho, se, type = "l")
