rm(list=ls())
set.seed(1234)


library(car)
library(stargazer)
library(psych)
library(GPArotation)


modeldata<-read.csv("MTurkData.csv")

#Those who pass manipulation checks, remove line of code to produce Appendix Table A13
modeldata<-subset(modeldata, modeldata$Check1Women == 0 | modeldata$Check1Women == 4)

#Subset 4 main treatment conditions 
MainData<-subset(modeldata, TreatName=="AMPHarassIncrease" | TreatName =="AMPHarrassDecrease" | TreatName =="GBPHarrassDecrease" | TreatName =="GBPHarrassIncrease")

#Reverse code overturn variable 
MainData$OverturnR<-recode(MainData$Overturn, "1=4; 2=3; 3=2; 4=1")

#Appendix Table A2 
#run code without "chisq.test" command to see differences in means 

chisq.test(tapply(MainData $Female, MainData $treatment, mean))
chisq.test(tapply(MainData $age, MainData $treatment, mean))
chisq.test(tapply(MainData $Edu, MainData $treatment, mean))
chisq.test(tapply(MainData $White, MainData $treatment, mean))
chisq.test(tapply(MainData $Dem, MainData $treatment, mean))
chisq.test(tapply(MainData $Rep, MainData $treatment, mean))
chisq.test(tapply(MainData $Ind, MainData $treatment, mean))
chisq.test(tapply(MainData $PreventSexHarass, MainData $treatment, mean))


#Appendix Figure A3
#Individual question plots 
par(mfrow=c(3,3))
barplot(tapply(MainData$RightDecision, MainData$treatment, mean)[c(1,3,2,4)], main="Outcome Right for Citizens", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(MainData$RightDecisionGroup, MainData$treatment, mean)[c(1,3,2,4)], main="Outcome Right for Women", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(MainData$FairDecision, MainData$treatment, mean)[c(1,3,2,4)], main="Outcome Fair for Women", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(MainData$PersonalAgree, MainData$treatment, mean)[c(1,3,2,4)], main="Personal Agreement", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(MainData$FairProcess, MainData$treatment, mean)[c(1,3,2,4)], main="Process Fair for Women", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(MainData$Overturn, MainData$treatment, mean)[c(1,3,2,4)], main="Overturn Decision", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
barplot(tapply(MainData$TrustCommittee, MainData$treatment, mean)[c(1,3,2,4)], main="Trust Committee", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(MainData$TrustLegislature, MainData$treatment, mean)[c(1,3,2,4)], main="Trust Legislature", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")

par(oma=c(0,0,2,0))
title(main="Sexual Harassment Vignettes - Seperate Outcomes \n MTurk Data",outer=T)


#Appendix Figure 1
factor<-MainData[,c(3:5, 12, 6, 28, 8, 10)]
p2 <-fa(factor, 2,  rotate="Promax")
fa.diagram(p2)

#Appendix Table A4 
lowerCor(factor)


##Create factor data with omega function in psych package
#Substantive legitimacy scale
factor1<-omega(MainData[,c(3:5)], nfactors=1) 
MainData $Substance<-factor1$scores[,1]
summary(MainData $Substance)

#procedural legitimacy scale 
factor2<-omega(MainData[,c(6,8, 28, 10)], nfactors=1) 
MainData$Procedure<-factor2$scores[,1]
summary(MainData$Procedure)


#Manuscript Figure 1, right panel
par(mfrow=c(1,2))
barplot(tapply(MainData$Substance, MainData$treatment, mean)[c(1,3,2,4)], main="Substantive Legitimacy \n MTurk Data", beside=T,ylim=c(1,4),xpd=FALSE, ylab=c("mean"), xaxt="n")  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.507552 +(1* 0.07199651), x1=0.7, y1= 1.507552-(1* 0.07199651), lwd=2, col='black')
segments(x0=1.9, y0= 1.938011 +(1* 0.07199651), x1=1.9, y1= 1.938011-(1* 0.07199651), lwd=2, col='black')
segments(x0=3.1, y0= 3.428273 +(1* 0.08412026), x1=3.1, y1= 3.428273-(1* 0.08412026), lwd=2, col='black')
segments(x0=4.3, y0= 3.532764 +(1* 0.08412026), x1=4.3, y1= 3.532764-(1* 0.08412026), lwd=2, col='black')


#Manuscript Table 1, MTurk data (row 2)
t.test(subset(MainData$Substance, MainData$TreatName == 'GBPHarrassDecrease'), subset(MainData$Substance, MainData$TreatName == 'AMPHarrassDecrease'))
t.test(subset(MainData$Substance, MainData$TreatName == 'GBPHarrassIncrease'), subset(MainData$Substance, MainData$TreatName == 'AMPHarassIncrease'))


#Manuscript Figure 4, right panel
barplot(tapply(MainData$Procedure, MainData$treatment, mean)[c(1,3,2,4)], main="Procedural Legitimacy \n MTurk Data", beside=T,ylim=c(1,4),  xpd=FALSE, ylab=c("mean"), xaxt="n")  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.774927 +(1* 0.07974188), x1=0.7, y1= 1.774927-(1* 0.07974188), lwd=2, col='black')
segments(x0=1.9, y0= 2.887725 +(1* 0.07974188), x1=1.9, y1= 2.887725-(1* 0.07974188), lwd=2, col='black') 
segments(x0=3.1, y0= 3.228571 +(1* 0.06300142), x1=3.1, y1= 3.228571-(1* 0.06300142), lwd=2, col='black')
segments(x0=4.3, y0= 3.762615 +(1* 0.06306241), x1=4.3, y1= 3.762615-(1* 0.06306241), lwd=2, col='black')


#Manuscript Table 3, MTurk data (row 2)
t.test(subset(MainData$Procedure, MainData$TreatName == 'GBPHarrassDecrease'), subset(MainData$Procedure, MainData$TreatName == 'AMPHarrassDecrease'))
t.test(subset(MainData$Procedure, MainData$TreatName == 'GBPHarrassIncrease'), subset(MainData$Procedure, MainData$TreatName == 'AMPHarassIncrease'))


##Results by gender
men<-subset(MainData, Female==0)
women<-subset(MainData, Female==1)

SubstanceM<-tapply(men$Substance, men$treatment, mean)
SubstanceW<-tapply(women$Substance, women$treatment, mean)
SubstanceMatrix <-cbind(SubstanceW, SubstanceM)
SubstanceMatrix <-rbind(SubstanceMatrix[c(1,3),], SubstanceMatrix[c(2,4),]) 

ProcedureM<-tapply(men$Procedure, men$treatment, mean)
ProcedureW <-tapply(women$Procedure, women$treatment, mean)
ProcedureMatrix <-cbind(ProcedureW, ProcedureM)
ProcedureMatrixMTurk <-rbind(ProcedureMatrix[c(1,3),], ProcedureMatrix[c(2,4),]) 

#Manuscript Figure 2, right column 
par(mfrow=c(1,2))

barplot(t(SubstanceMatrix), beside=T, col=c('black', 'grey'), main="Substantive Legitimacy \n MTurk Data",ylim=c(1,4), xpd=FALSE, ylab=c("mean"), xaxt="n", space=rep(c(0.2,0),4), legend=c("Women", "Men"), args.legend = list(x = "topleft", cex = .8))
axis(1, at=c(1.2, 3.4, 5.6, 7.8), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")

segments(x0=0.7, y0= 1.410102 +(1* 0.09770251), x1=0.7, y1= 1.410102-(1* 0.09770251), lwd=2, col='grey')
segments(x0=2.9, y0= 1.777495 +(1* 0.09770251), x1=2.9, y1= 1.777495-(1* 0.09770251), lwd=2, col='grey')
segments(x0=5.1, y0= 3.547972 +(1* 0.08441749), x1=5.1, y1= 3.547972-(1* 0.08441749), lwd=2, col='grey')
segments(x0=7.3, y0= 3.585195 +(1* 0.08441749), x1=7.3, y1= 3.585195-(1* 0.08441749), lwd=2, col='grey')
segments(x0=1.7, y0= 1.610819 +(1* 0.1028725), x1=1.7, y1= 1.610819-(1* 0.1028725), lwd=2, col='black')
segments(x0=3.9, y0= 2.085272 +(1* 0.1028725), x1=3.9, y1= 2.085272-(1* 0.1028725), lwd=2, col='black')
segments(x0=6.1, y0= 3.310674 +(1* 0.09734797), x1=6.1, y1= 3.310674-(1* 0.09734797), lwd=2, col='black')
segments(x0=8.3, y0= 3.477812 +(1* 0.09734797), x1=8.3, y1= 3.477812-(1* 0.09734797), lwd=2, col='black')


#Manuscript Table 2, MTurk data (row 2 and row 4)
t.test(subset(men $Substance, men $TreatName == 'GBPHarrassDecrease'), subset(men $Substance, men $TreatName == 'AMPHarrassDecrease'))
t.test(subset(men $Substance, men $TreatName == 'GBPHarrassIncrease'), subset(men $Substance, men $TreatName == 'AMPHarassIncrease'))
t.test(subset(women $Substance, women $TreatName == 'GBPHarrassDecrease'), subset(women $Substance, women $TreatName == 'AMPHarrassDecrease'))
t.test(subset(women $Substance, women $TreatName == 'GBPHarrassIncrease'), subset(women $Substance, women $TreatName == 'AMPHarassIncrease'))


#Appendix Figure 4, right panel
barplot(t(ProcedureMatrixMTurk), beside=T, col=c('black', 'grey'), main="Procedural Legitimacy \n MTurk Data",ylim=c(1,4),xpd=FALSE, ylab=c("mean"), xaxt="n", space=rep(c(0.2,0),4), legend=c("Women", "Men"), args.legend = list(x = "topleft", cex = .8))
axis(1, at=c(1.2, 3.4, 5.6, 7.8), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.596219 +(1* 0.09738407), x1=0.7, y1= 1.596219-(1* 0.09738407), lwd=2, col='grey')
segments(x0=2.9, y0= 2.835886 +(1* 0.09738407), x1=2.9, y1= 2.835886-(1* 0.09738407), lwd=2, col='grey')
segments(x0=5.1, y0= 3.228475 +(1* 0.08289803), x1=5.1, y1= 3.228475-(1* 0.08289803), lwd=2, col='grey')
segments(x0=7.3, y0= 3.900270 +(1* 0.08289803), x1=7.3, y1= 3.900270-(1* 0.08289803), lwd=2, col='grey')
segments(x0=1.7, y0= 1.964705 +(1* 0.1184209), x1=1.7, y1= 1.964705-(1* 0.1184209), lwd=2, col='black')
segments(x0=3.9, y0= 2.935285 +(1* 0.1184209), x1=3.9, y1= 2.935285-(1* 0.1184209), lwd=2, col='black')
segments(x0=6.1, y0= 3.228665 +(1* 0.1143513), x1=6.1, y1= 3.228665-(1* 0.1143513), lwd=2, col='black')
segments(x0=8.3, y0= 3.618343 +(1* 0.1143513), x1=8.3, y1= 3.618343-(1* 0.1143513), lwd=2, col='black')


#Appendix Table 8, MTurk data (row 2 and row 4)
t.test(subset(men $Procedure, men $TreatName == 'GBPHarrassDecrease'), subset(men $Procedure, men $TreatName == 'AMPHarrassDecrease'))
t.test(subset(men $Procedure, men $TreatName == 'GBPHarrassIncrease'), subset(men $Procedure, men $TreatName == 'AMPHarassIncrease'))
t.test(subset(women $Procedure, women $TreatName == 'GBPHarrassDecrease'), subset(women $Procedure, women $TreatName == 'AMPHarrassDecrease'))
t.test(subset(women $Procedure, women $TreatName == 'GBPHarrassIncrease'), subset(women $Procedure, women $TreatName == 'AMPHarassIncrease'))


#Appendix Table A6
#MTurk gender diff-in-diff
AntiFem<-subset(MainData, TreatName=="GBPHarrassDecrease" | TreatName =="AMPHarrassDecrease")
lm1<-lm(Substance ~ treatment + Female + (treatment*Female), data=AntiFem )
summary(lm1) #p = 0.466


#Appendix Table A7
#stacking MTurk and CCES data 
AntiFemCESS<-read.csv('AntiFemCESS.csv')

StackedCESS<-AntiFemCESS[, c(1,9, 15)]
StackedCESS$Treatment<-recode(StackedCESS$Treatment, "'AntiAMP' = 0; 'AntiGBP'=1")
StackedCESS$CCES<-rep(1, nrow(AntiFemCESS))
StackedMT<-AntiFem[, c(2, 19, 29)]
StackedMT$treatment<-recode(StackedMT$treatment, "'1' = 0; '3'=1")
StackedMT $CCES<-rep(0, nrow(StackedMT))

names(StackedMT)<-names(StackedCESS)
Stacked<-rbind(StackedCESS, StackedMT)
lm2<-lm(Substance ~ Treatment + Female + (Treatment*Female)+ CCES, data=Stacked )
summary(lm2) #p = 0.09

##by sexual harassment saliance 

t.test(PreventSexHarass~Female, data=modeldata)
prop.table(table(modeldata$PreventSexHarass, modeldata$Female), 2)

Imp<-subset(MainData, MainData $PreventSexHarass == 4 | MainData $PreventSexHarass == 1 )
NoImp<-subset(MainData, MainData $PreventSexHarass == 3 | MainData $PreventSexHarass == 2)

#Figure 3

SubstanceImp<-tapply(Imp $Substance, Imp $treatment, mean)
SubstanceNoImp<-tapply(NoImp $Substance, NoImp $treatment, mean)
SubstanceMatrix <-cbind(SubstanceImp, SubstanceNoImp)
SubstanceMatrix <-rbind(SubstanceMatrix[c(1,3),], SubstanceMatrix[c(2,4),]) 

par(mfrow=c(1,1))

barplot(t(SubstanceMatrix), beside=T, col=c('black', 'grey'), main="Substantive Legitimacy \n By Issue Salience ",ylim=c(1,4), xpd=FALSE, ylab=c("mean"), xaxt="n", space=rep(c(0.2,0),4), legend=c("Certain", "Uncertain"), args.legend = list(x = "topleft"))
axis(1, at=c(1.2, 3.4, 5.6, 7.8), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.287086 +(1* 0.08367824), x1=0.7, y1= 1.287086-(1* 0.08367824), lwd=2, col='grey')
segments(x0=1.7, y0= 1.962662 +(1* 0.1147524), x1=1.7, y1= 1.962662-(1* 0.1147524), lwd=2, col='black')
segments(x0=2.9, y0= 1.673077 +(1* 0.08367824), x1=2.9, y1= 1.673077-(1* 0.08367824), lwd=2, col='grey')
segments(x0=3.9, y0= 2.452953 +(1* 0.1147524), x1=3.9, y1= 2.452953-(1* 0.1147524), lwd=2, col='black')
segments(x0=5.1, y0= 3.602521 +(1* 0.07600179), x1=5.1, y1= 3.602521-(1* 0.07600179), lwd=2, col='grey')
segments(x0=6.1, y0= 3.063068 +(1* 0.1213666), x1=6.1, y1= 3.063068-(1* 0.1213666), lwd=2, col='black')
segments(x0=7.3, y0= 3.653351 +(1* 0.07600179), x1=7.3, y1= 3.653351-(1* 0.07600179), lwd=2, col='grey')
segments(x0=8.3, y0= 3.245651 +(1* 0.1205168), x1=8.3, y1= 3.245651-(1* 0.1205168), lwd=2, col='black')

t.test(subset(Imp $Substance, Imp $TreatName == 'AMPHarrassDecrease'), subset(Imp $Substance, Imp $TreatName == 'GBPHarrassDecrease')) #
t.test(subset(NoImp $Substance, NoImp $TreatName == 'AMPHarrassDecrease'), subset(NoImp $Substance, NoImp $TreatName == 'GBPHarrassDecrease')) #

t.test(subset(Imp $Substance, Imp $TreatName == 'AMPHarassIncrease'), subset(Imp $Substance, Imp $TreatName == 'GBPHarrassIncrease')) #
t.test(subset(NoImp $Substance, NoImp $TreatName == 'AMPHarassIncrease'), subset(NoImp $Substance, NoImp $TreatName == 'GBPHarrassIncrease')) #


##Difference in difference by issue salience 

DiffTest<-subset(MainData, MainData $TreatName == "AMPHarrassDecrease" | MainData $TreatName == "GBPHarrassDecrease")
DiffTest$TreatmentGB<-recode(DiffTest$TreatName, "'GBPHarrassDecrease' = 1; else =0")
DiffTest$TreatmentGB<-as.numeric(as.character(DiffTest$TreatmentGB))
DiffTest$Certain<-recode(DiffTest$PreventSexHarass, "c(4,1) = 1; else =0")

model1<-lm(Substance ~ TreatmentGB + Certain + I(TreatmentGB* Certain), data=DiffTest)
summary(model1)


#Animal Mistreatment Issue

Animal<-subset(modeldata, TreatName=="AMPAnimalDecrease" | TreatName =="AMPAnimalIncrease" | TreatName =="GBPAnimalDecrease" | TreatName =="GBPAnimalIncrease")

factor1<-omega(Animal[,c(3:5)], nfactors=1) #alpha = 0.94
Animal $Substance<-factor1$scores[,1]
summary(Animal $Substance)

Animal $OverturnR<-recode(Animal $Overturn, "1=4; 2=3; 3=2; 4=1")

factor2<-omega(Animal[,c(6, 8,10, 29)], nfactors=1) #alpha = 0.89
Animal $Procedure<-factor2$scores[,1]
summary(Animal $Procedure)


#Manuscript Figure 5
par(mfrow=c(1,2))
barplot(tapply(Animal $Substance, Animal $treatment, mean)[c(1,3,2,4)], main="Substantive Legitimacy", beside=T, ylim=c(1,4),xpd=FALSE, ylab=c("mean"), xaxt="n")  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Decrease \n AMP", "Decrease \n GBP", "Increase \n AMP", "Increase \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.559687 +(1* 0.06955423), x1=0.7, y1= 1.559687-(1* 0.06955423), lwd=2, col='black')
segments(x0=1.9, y0= 1.608767 +(1* 0.06955423), x1=1.9, y1= 1.608767-(1* 0.06955423), lwd=2, col='black')
segments(x0=3.1, y0= 3.592185 +(1* 0.06055086), x1=3.1, y1= 3.592185-(1* 0.06055086), lwd=2, col='black')
segments(x0=4.3, y0= 3.594093 +(1* 0.06055086), x1=4.3, y1= 3.594093-(1* 0.06055086), lwd=2, col='black')


barplot(tapply(Animal $Procedure, Animal $treatment, mean)[c(1,3,2,4)], main="Procedural Legitimacy", beside=T,ylim=c(1,4),  xpd=FALSE, ylab=c("mean"), xaxt="n")  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Decrease \n AMP", "Decrease \n GBP", "Increase \n AMP", "Increase \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 2.378404 +(1* 0.07630193), x1=0.7, y1= 2.378404-(1* 0.07630193), lwd=2, col='black')
segments(x0=1.9, y0= 3.066037 +(1* 0.07630193), x1=1.9, y1= 3.066037-(1* 0.07630193), lwd=2, col='black')
segments(x0=3.1, y0= 3.445431 +(1* 0.0581029), x1=3.1, y1= 3.445431-(1* 0.0581029), lwd=2, col='black')
segments(x0=4.3, y0= 3.876264 +(1* 0.0581029), x1=4.3, y1= 3.876264-(1* 0.0581029), lwd=2, col='black')

par(oma=c(0,0,2,0))
title(main="Animal Mistreatment Vignettes",outer=T)

t.test(subset(Animal$Procedure, Animal$TreatName == 'AMPAnimalDecrease'), subset(Animal$Procedure, Animal $TreatName == 'GBPAnimalDecrease'))
t.test(subset(Animal$Procedure, Animal$TreatName == 'AMPAnimalIncrease'), subset(Animal$Procedure, Animal $TreatName == 'GBPAnimalIncrease'))


##Further Robustness Checks 
##No headline 

Headline<-subset(modeldata, TreatName=="AMPHeadlineDecrease" | TreatName =="AMPHeadlineIncrease" | TreatName =="GBPHeadlineDecrease" | TreatName =="GBPHeadlineIncrease")

factor1<-omega(Headline[,c(3:5)], nfactors=1) #alpha = 0.96
Headline $Substance<-factor1$scores[,1]
summary(Headline $Substance)

Headline $OverturnR<-recode(Headline $Overturn, "1=4; 2=3; 3=2; 4=1")
factor2<-omega(Headline[,c(6, 8, 10, 29)], nfactors=1) #alpha = 0.89
Headline $Procedure<-factor2$scores[,1]
summary(Headline $Procedure)

#Appendix Table A9
t.test(subset(Headline$Substance, Headline $TreatName == 'AMPHeadlineDecrease'), subset(Headline$Substance, Headline $TreatName == 'GBPHeadlineDecrease')) 
t.test(subset(Headline$Substance, Headline $TreatName == 'AMPHeadlineIncrease'), subset(Headline$Substance, Headline $TreatName == 'GBPHeadlineIncrease')) 
t.test(subset(Headline$Procedure, Headline $TreatName == 'AMPHeadlineDecrease'), subset(Headline$Procedure, Headline $TreatName == 'GBPHeadlineDecrease')) 
t.test(subset(Headline$Procedure, Headline $TreatName == 'AMPHeadlineIncrease'), subset(Headline$Procedure, Headline $TreatName == 'GBPHeadlineIncrease')) 

#No Prompt in Question Wording

NoPrompt<-read.csv('NoPromptRobust.csv')

factor1<-omega(NoPrompt[,c(1:3)], nfactors=1) 
NoPrompt $Substance<-factor1$scores[,1]
summary(NoPrompt $Substance)
NoPrompt $Overturn<-recode(NoPrompt $Overturn, "1=4; 2=3; 3=2;4=1")
factor2<-omega(NoPrompt[,c(4:7)], nfactors=1) #alpha = 0.93
NoPrompt $Procedure<-factor2$scores[,1]
summary(NoPrompt $Procedure)

#Appendix Table A10
t.test(subset(NoPrompt$Substance, NoPrompt$TreatName == 'AMPAnti'), subset(NoPrompt$Substance, NoPrompt$TreatName == 'GBPAnti'))
t.test(subset(NoPrompt$Substance, NoPrompt$TreatName == 'AMPFem'), subset(NoPrompt$Substance, NoPrompt$TreatName == 'GBPFem'))
t.test(subset(NoPrompt $Procedure, NoPrompt $TreatName == 'AMPAnti'), subset(NoPrompt $Procedure, NoPrompt $TreatName == 'GBPAnti'))
t.test(subset(NoPrompt $Procedure, NoPrompt $TreatName == 'AMPFem'), subset(NoPrompt $Procedure, NoPrompt $TreatName == 'GBPFem'))


#Replication with different survey timing 
Rep<-read.csv("Replication.csv")

factor1<-omega(Rep[,c(5:7)], nfactors=1) 
Rep$Substance<-factor1$scores[,1]
summary(Rep$Substance)

Rep$Overturn<-recode(Rep$Overturn, "1=4; 2=3; 3=2;4=1")

factor2<-omega(Rep[,c(8:11)], nfactors=1) 
Rep$Procedure<-factor2$scores[,1]
summary(Rep$Procedure)

#Appendix Table A12
t.test(subset(Rep$Substance, Rep$TreatName == 'AMPAnti'), subset(Rep$Substance, Rep$TreatName == 'GBPAnti'))
t.test(subset(Rep$Substance, Rep$TreatName == 'AMPFem'), subset(Rep$Substance, Rep$TreatName == 'GBPFem'))
t.test(subset(Rep$Procedure, Rep$TreatName == 'AMPAnti'), subset(Rep$Procedure, Rep$TreatName == 'GBPAnti'))
t.test(subset(Rep$Procedure, Rep$TreatName == 'AMPFem'), subset(Rep$Procedure, Rep$TreatName == 'GBPFem'))


#among those with low social desirability bias   
SocDesire<-subset(Rep, Rep$SocDesire < mean(Rep$SocDesire))

#Appendix Table A11
t.test(subset(SocDesire $Substance, SocDesire $TreatName == 'AMPAnti'), subset(SocDesire $Substance, SocDesire$TreatName == 'GBPAnti'))
t.test(subset(SocDesire $Substance, SocDesire $TreatName == 'AMPFem'), subset(SocDesire $Substance, SocDesire $TreatName == 'GBPFem'))
t.test(subset(SocDesire $Procedure, SocDesire $TreatName == 'AMPAnti'), subset(SocDesire $Procedure, SocDesire $TreatName == 'GBPAnti'))
t.test(subset(SocDesire $Procedure, SocDesire $TreatName == 'AMPFem'), subset(SocDesire $Procedure, SocDesire $TreatName == 'GBPFem'))


#Extension: One-Woman Panel 

modeldata<-read.csv("Extension.csv")

modeldata $OverturnR<-recode(modeldata $Overturn, "1=4; 2=3; 3=2; 4=1")

factor1<-omega(modeldata[,c(1:3)], nfactors=1) #alpha = 0.96
modeldata $Substance<-factor1$scores[,1]

factor2<-omega(modeldata[,c(4,6,8,13)], nfactors=1) #alpha = 0.96
modeldata $Procedure<-factor2$scores[,1]

Fem<-subset(modeldata, TreatName=="OneWomanIncrease" | TreatName=="AMPHeadlineIncrease" )
Anti<-subset(modeldata, TreatName=="OneWomanDecrease" | TreatName=="AMPHeadlineDecrease" )

#Appendix Table A14
t.test(Substance~Treatment, data=Fem)  
t.test(Procedure~Treatment, data=Fem) 
t.test(Substance~Treatment, data=Anti) 
t.test(Procedure~Treatment, data=Anti) 



