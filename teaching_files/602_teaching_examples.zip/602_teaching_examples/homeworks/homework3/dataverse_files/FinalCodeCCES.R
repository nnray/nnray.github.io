rm(list=ls())
set.seed(1234)


library(car)
library(psych)
library(GPArotation)


modeldata<-read.csv('CCES.csv')

modeldata$Rep<-recode(modeldata$PartyID, "c(1,2,3)=1; else=0")
modeldata$Rep<-as.numeric(as.character(modeldata$Rep))

modeldata$Dem<-recode(modeldata$PartyID, "c(5,6,7)=1; else=0")
modeldata$Dem<-as.numeric(as.character(modeldata$Dem))

modeldata$Ind<-recode(modeldata$PartyID, "4=1; else=0")
modeldata$Ind<-as.numeric(as.character(modeldata$Ind))

modeldata$OverturnR<-recode(modeldata$Overturn, "1=4; 2=3; 3=2; 4=1")


#Appendix Table A1
# Balance
#run code without "chisq.test" command to see differences in means 
chisq.test(tapply(modeldata$Female, modeldata$Treatment, mean))
chisq.test(tapply(modeldata$BirthYr, modeldata$Treatment, mean))
chisq.test(tapply(modeldata$Edu, modeldata$Treatment, mean))
chisq.test(tapply(modeldata$White, modeldata$Treatment, mean))
chisq.test(tapply(modeldata$Dem, modeldata$Treatment, mean))
chisq.test(tapply(modeldata$Rep, modeldata$Treatment, mean))
chisq.test(tapply(modeldata$Ind, modeldata$Treatment, mean))


#Appendix Figure A2
#Individual question plots 
par(mfrow=c(2,3))
barplot(tapply(modeldata$RightWomen, modeldata$Treatment, mean), main="Outcome Right for Women", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(modeldata $FairWomen, modeldata $Treatment, mean), main="Outcome Fair for Women", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(modeldata $Agree, modeldata $Treatment, mean), main="Personal Agreement", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(modeldata $ProcessFair, modeldata $Treatment, mean), main="Process Fair for Women", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
barplot(tapply(modeldata $Overturn, modeldata $Treatment, mean), main="Overturn Decision", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
barplot(tapply(modeldata $TrustCom, modeldata $Treatment, mean), main="Trust Committee", beside=T,ylim=c(1,4), ylab=c("mean"), xaxt="n", xpd=FALSE)  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")


#Appendix Table A3
##Reverse code overturn 
cortable<-modeldata[,c(2:3, 7, 4, 17, 6)]
r<-lowerCor(cortable)


##Create factor data with omega function in psych package
#Substantive legitimacy scale
factor1<-omega(modeldata[,c(2:3)], nfactors=1) 
modeldata$Substance<-factor1$scores[,1]
summary(modeldata$Substance)

#Procedural legitimacy scale
factor2<-omega(modeldata[,c(4,6,17)], nfactors=1) 
modeldata$Procedure<-factor2$scores[,1]
summary(modeldata$Procedure)


#Manuscript Figure 1, left panel 
par(mfrow=c(1,2))
barplot(tapply(modeldata$Substance, modeldata$Treatment, mean), main="Substantive Legitimacy \n CCES Data", beside=T,ylim=c(1,4),xpd=FALSE, ylab=c("mean"), xaxt="n")  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.829204 +(1* 0.09269462), x1=0.7, y1= 1.829204-(1* 0.09269462), lwd=2, col='black')
segments(x0=1.9, y0= 2.258343 +(1* 0.09269462), x1=1.9, y1= 2.258343-(1* 0.09269462), lwd=2, col='black')
segments(x0=3.1, y0= 3.226806 +(1* 0.06559114), x1=3.1, y1= 3.226806-(1* 0.06559114), lwd=2, col='black')
segments(x0=4.3, y0= 3.213125 +(1* 0.06559114), x1=4.3, y1= 3.213125-(1* 0.06559114), lwd=2, col='black')


#Manuscript Table 1, CCES data (first row)
t.test(subset(modeldata $Substance, modeldata $Treatment == 'AntiGBP'), subset(modeldata $Substance, modeldata $Treatment == 'AntiAMP'))
t.test(subset(modeldata $Substance, modeldata $Treatment == 'FemGBP'), subset(modeldata $Substance, modeldata $Treatment == 'FemAMP'))


#Manuscript Figure 4, left panel 
barplot(tapply(modeldata$Procedure, modeldata$Treatment, mean), main="Procedural Legitimacy \n CCES Data", beside=T,ylim=c(1,4),  xpd=FALSE, ylab=c("mean"), xaxt="n")  
axis(1, at=c(0.7, 1.9, 3.1, 4.3), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.878685 +(1* 0.08433352), x1=0.7, y1= 1.878685-(1* 0.08433352), lwd=2, col='black')
segments(x0=1.9, y0= 2.786957 +(1* 0.08433352), x1=1.9, y1= 2.786957-(1* 0.08433352), lwd=2, col='black')
segments(x0=3.1, y0= 2.886941 +(1* 0.06821521), x1=3.1, y1= 2.886941-(1* 0.06821521), lwd=2, col='black')
segments(x0=4.3, y0= 3.323034 +(1* 0.06821521), x1=4.3, y1= 3.323034-(1* 0.06821521), lwd=2, col='black')


#Manuscript Table 3, CCES data (first row) 
t.test(subset(modeldata $Procedure, modeldata $Treatment == 'AntiGBP'), subset(modeldata $Procedure, modeldata $Treatment == 'AntiAMP'))
t.test(subset(modeldata $Procedure, modeldata $Treatment == 'FemGBP'), subset(modeldata $Procedure, modeldata $Treatment == 'FemAMP'))


##Results by gender 
men<-subset(modeldata, Female==0)
women<-subset(modeldata, Female==1)
SubstanceM<-tapply(men$Substance, men$Treatment, mean)
SubstanceW<-tapply(women$Substance, women$Treatment, mean)
SubstanceMatrix <-cbind(SubstanceW, SubstanceM)
ProcedureM<-tapply(men$Procedure, men$Treatment, mean)
ProcedureW <-tapply(women$Procedure, women$Treatment, mean)
ProcedureMatrixCCES <-cbind(ProcedureW, ProcedureM)


#Manuscript Figure 2, left panel 
par(mfrow=c(1,2))
barplot(t(SubstanceMatrix), beside=T, col=c('black', 'grey'), main="Substantive Legitimacy \n CCES Data",ylim=c(1,4), xpd=FALSE, ylab=c("mean"), xaxt="n", space=rep(c(0.2,0),4), legend=c("Women", "Men"), args.legend = list(x = "topleft", cex = .8))
axis(1, at=c(1.2, 3.4, 5.6, 7.8), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.783474 +(1* 0.1216006), x1=0.7, y1= 1.783474-(1* 0.1216006), lwd=2, col='grey')
segments(x0=2.9, y0= 2.074525 +(1* 0.1216006), x1=2.9, y1= 2.074525-(1* 0.1216006), lwd=2, col='grey')
segments(x0=5.1, y0= 3.302622 +(1* 0.08094839), x1=5.1, y1= 3.302622-(1* 0.08094839), lwd=2, col='grey')
segments(x0=7.3, y0= 3.230208 +(1* 0.08094839), x1=7.3, y1= 3.230208-(1* 0.08094839), lwd=2, col='grey')
segments(x0=1.7, y0= 1.890177 +(1* 0.1397796), x1=1.7, y1= 1.890177-(1* 0.1397796), lwd=2, col='black')
segments(x0=3.9, y0= 2.476762 +(1* 0.1397796), x1=3.9, y1= 2.476762-(1* 0.1397796), lwd=2, col='black')
segments(x0=6.1, y0= 3.119332 +(1* 0.108715), x1=6.1, y1= 3.119332-(1* 0.108715), lwd=2, col='black')
segments(x0=8.3, y0= 3.190599 +(1* 0.108715), x1=8.3, y1= 3.190599-(1* 0.108715), lwd=2, col='black')


#Manuscript Table 2, CCES data (row 1 and row 3) 
t.test(subset(men $Substance, men $Treatment == 'AntiGBP'), subset(men $Substance, men $Treatment == 'AntiAMP'))
t.test(subset(men $Substance, men $Treatment == 'FemGBP'), subset(men $Substance, men $Treatment == 'FemAMP'))
t.test(subset(women $Substance, women $Treatment == 'AntiGBP'), subset(women $Substance, women $Treatment == 'AntiAMP'))
t.test(subset(women $Substance, women $Treatment == 'FemGBP'), subset(women $Substance, women $Treatment == 'FemAMP'))


#Appendix Figure A4, left panel
barplot(t(ProcedureMatrixCCES), beside=T, col=c('black', 'grey'), main="Procedural Legitimacy \n CCES Data",ylim=c(1,4),xpd=FALSE, ylab=c("mean"), xaxt="n", space=rep(c(0.2,0),4),  legend=c("Women", "Men"), args.legend = list(x = "topleft", cex = .8))
axis(1, at=c(1.2, 3.4, 5.6, 7.8), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")
segments(x0=0.7, y0= 1.785730 +(1* 0.09864609), x1=0.7, y1= 1.785730-(1* 0.09864609), lwd=2, col='grey')
segments(x0=2.9, y0= 2.615868 +(1* 0.09864609), x1=2.9, y1= 2.615868-(1* 0.09864609), lwd=2, col='grey')
segments(x0=5.1, y0= 2.943199 +(1* 0.08298623), x1=5.1, y1= 2.943199-(1* 0.08298623), lwd=2, col='grey')
segments(x0=7.3, y0= 3.311595 +(1* 0.08298623), x1=7.3, y1= 3.311595-(1* 0.08298623), lwd=2, col='grey')
segments(x0=1.7, y0= 2.002626 +(1* 0.1264223), x1=1.7, y1= 2.002626-(1* 0.1264223), lwd=2, col='black')
segments(x0=3.9, y0= 2.990252 +(1* 0.1264223), x1=3.9, y1= 2.990252-(1* 0.1264223), lwd=2, col='black')
segments(x0=6.1, y0= 2.807191 +(1* 0.09497163), x1=6.1, y1= 2.807191-(1* 0.09497163), lwd=2, col='black')
segments(x0=8.3, y0= 3.338117 +(1* 0.09497163), x1=8.3, y1= 3.338117-(1* 0.09497163), lwd=2, col='black')


#Appendix Table A8, CCES data (row 1 and row 3)
t.test(subset(men$Procedure, men $Treatment == 'AntiGBP'), subset(men $Procedure, men $Treatment == 'AntiAMP'))
t.test(subset(men $Procedure, men $Treatment == 'FemGBP'), subset(men $Procedure, men $Treatment == 'FemAMP'))
t.test(subset(women$Procedure, women $Treatment == 'AntiGBP'), subset(women $Procedure, women $Treatment == 'AntiAMP'))
t.test(subset(women $Procedure, women $Treatment == 'FemGBP'), subset(women $Procedure, women $Treatment == 'FemAMP'))


#Manuscript Figure 6
Rep<-subset(modeldata, PartyID < 4)
Dem<-subset(modeldata, PartyID > 4)

SubstanceR <-tapply(Rep $Substance, Rep $Treatment, mean)
SubstanceD <-tapply(Dem$Substance, Dem$Treatment, mean)
SubstanceMatrix <-cbind(SubstanceD, SubstanceR)

ProcedureR<-tapply(Rep $Procedure, Rep $Treatment, mean)
ProcedureD <-tapply(Dem$Procedure, Dem$Treatment, mean)
ProcedureMatrix <-cbind(ProcedureD, ProcedureR)

par(mfrow=c(1,2))

barplot(t(SubstanceMatrix), beside=T, col=c('black', 'grey'), main="Substantive Legitimacy",ylim=c(1,4), xpd=FALSE, ylab=c("mean"), xaxt="n", space=rep(c(0.2,0),4), legend=c("Democrats", "Republicans"), args.legend = list(x = "topleft", cex = .8))
axis(1, at=c(1.2, 3.4, 5.6, 7.8), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")

segments(x0=0.7, y0= 1.647225 +(1* 0.1213083), x1=0.7, y1= 1.647225-(1* 0.1213083), lwd=2, col='grey')
segments(x0=1.7, y0= 2.118406 +(1* 0.1517728), x1=1.7, y1= 2.118406-(1* 0.1517728), lwd=2, col='black')
segments(x0=2.9, y0= 2.016724 +(1* 0.1213083), x1=2.9, y1= 2.016724-(1* 0.1213083), lwd=2, col='grey')
segments(x0=3.9, y0= 2.660660 +(1* 0.1517728), x1=3.9, y1= 2.660660-(1* 0.1517728), lwd=2, col='black')
segments(x0=5.1, y0= 3.408148 +(1* 0.08595049), x1=5.1, y1= 3.408148-(1* 0.08595049), lwd=2, col='grey')
segments(x0=6.1, y0= 3.098269 +(1* 0.1109502), x1=6.1, y1= 3.098269-(1* 0.1109502), lwd=2, col='black')
segments(x0=7.3, y0= 3.466664 +(1* 0.08595049), x1=7.3, y1= 3.466664-(1* 0.08595049), lwd=2, col='grey')
segments(x0=8.3, y0= 3.060658 +(1* 0.1109502), x1=8.3, y1= 3.060658-(1* 0.1109502), lwd=2, col='black')

barplot(t(ProcedureMatrix), beside=T, col=c('black', 'grey'), main="Procedural Legitimacy",ylim=c(1,4), xpd=FALSE, ylab=c("mean"), xaxt="n", space=rep(c(0.2,0),4), legend=c("Democrats", "Republicans"), args.legend = list(x = "topleft", cex = .8))
axis(1, at=c(1.2, 3.4, 5.6, 7.8), labels=c("Anti \n AMP", "Anti \n GBP", "Fem \n AMP", "Fem \n GBP"), cex.axis=0.8)
box(bty="l")

segments(x0=0.7, y0= 1.664235 +(1* 0.1092388), x1=0.7, y1= 1.664235-(1* 0.1092388), lwd=2, col='grey')
segments(x0=1.7, y0= 2.222581 +(1* 0.1418243), x1=1.7, y1= 2.222581-(1* 0.1418243), lwd=2, col='black')
segments(x0=2.9, y0= 2.525878 +(1* 0.1092388), x1=2.9, y1= 2.525878-(1* 0.1092388), lwd=2, col='grey')
segments(x0=3.9, y0= 3.215663 +(1* 0.1418243), x1=3.9, y1= 3.215663-(1* 0.1418243), lwd=2, col='black')
segments(x0=5.1, y0= 2.828667 +(1* 0.1003314), x1=5.1, y1= 2.828667-(1* 0.1003314), lwd=2, col='grey')
segments(x0=6.1, y0= 2.972691 +(1* 0.1197493), x1=6.1, y1= 2.972691-(1* 0.1197493), lwd=2, col='black')
segments(x0=7.3, y0= 3.506235 +(1* 0.1003314), x1=7.3, y1= 3.506235-(1* 0.1003314), lwd=2, col='grey')
segments(x0=8.3, y0= 3.246342 +(1* 0.1197493), x1=8.3, y1= 3.246342-(1* 0.1197493), lwd=2, col='black')


##Effect sizes associated with Figure 6
t.test(subset(Rep $Procedure, Rep $Treatment == 'AntiAMP'), subset(Rep $Procedure, Rep $Treatment == 'AntiGBP'))
t.test(subset(Rep $Procedure, Rep $Treatment == 'FemAMP'), subset(Rep $Procedure, Rep $Treatment == 'FemGBP'))
t.test(subset(Dem $Procedure, Dem $Treatment == 'AntiAMP'), subset(Dem $Procedure, Dem $Treatment == 'AntiGBP'))
t.test(subset(Dem $Procedure, Dem $Treatment == 'FemAMP'), subset(Dem $Procedure, Dem $Treatment == 'FemGBP'))


##Partisan difference-in-difference estimates (text associated with Figure 6)  

modeldata$Rep<-recode(modeldata$PartyID, "1:3 = 1; 5:7 = 0; else=NA")
modeldata$Dem<-recode(modeldata$PartyID, "1:3 = 0; 5:7 = 1; else=NA")

AntiFemCCES<-subset(modeldata, modeldata $Treatment == 'AntiGBP' | modeldata $Treatment == 'AntiAMP')
AntiFemCCES $Treatment<-recode(AntiFemCCES $Treatment, "'AntiAMP' = 0; 'AntiGBP'=1")

lm1<-lm(Substance~Treatment + Rep + Treatment* Rep, data= AntiFemCCES)
summary(lm1) #interaction not significant

lm2<-lm(Procedure~Treatment + Rep + Treatment* Rep, data= AntiFemCCES)
summary(lm2) #interaction not significant

FemCCES<-subset(modeldata, modeldata $Treatment == 'FemGBP' | modeldata $Treatment == 'FemAMP')
FemCCES $Treatment<-recode(FemCCES $Treatment, "'FemAMP' = 0; 'FemGBP'=1")

lm3<-lm(Procedure~Treatment + Rep + Treatment* Rep, data= FemCCES)
summary(lm3) ##interaction significant at 0.01


##Appendix Table A5

lm1<-lm(Substance~Treatment + Female + Treatment* Female, data= AntiFemCCES)
summary(lm1) #interaction significant at p=0.11



