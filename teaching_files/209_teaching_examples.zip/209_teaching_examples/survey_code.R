df<- df %>%
  select(-`Timestamp`,
         -`What is the NetID of the student who requested you to participate in this survey?`)
for (i in 1:length(df)){
  df[,i] <- as.numeric(gsub("\\..*","",df[[i]]))
}