clt<-function(samples){
  set.seed(1)
  means<-as.data.frame(matrix(c(rep(NA,samples)),
                                dimnames = list(1:samples,
                                                c("sample_means"))))
  for (i in 1:samples) {
    means[i,]<-mean(runif(10,-10,10)) 
  }
  return(hist(means$sample_means,
              main="Sampling Distribution",
              xlab="Sample Means",
              xlim=c(-10,10)))
}
clt(samples=10000)
