#homoskedasticity and no autocorrelation########################################
library(lmtest);library(tidyverse)
set.seed(1)
data<-data.frame(
  x=rnorm(1000)
)
for (i in 1:1000) {
  data$y[i]<-1+2*data$x[i]+rnorm(1000)[i]
}
model<-lm(y~x,data)
plot(model$residuals) #no obvious pattern
plot(model,which=3) #no obvious deviations from flat line
lmtest::bptest(model) #can't reject null of homoskedasticity
acf(model$residuals) #correlations between first residual and its lags don't seem large
lmtest::dwtest(model) #can't reject null of no autocorrelation assuming AR(1) errors
lmtest::bgtest(model,order=2) #can't reject null of no autocorrelation assuming AR(2) errors
#heteroskedasticity#############################################################
for (i in 1:1000) {
  data$y2[i]<-1+2*data$x[i]+rnorm(1000)[i]
}
data<-mutate(data,y2=ifelse(x>1,rnorm(1000),y2)) #inducing heteroskedasticity
model2<-lm(y2~x,data)
plot(model2$residuals) #hard to tell any pattern from the residuals still
plot(model2,which=3) #but this line isn't flat
lmtest::bptest(model2) #can reject the null of homoskedasticity
lmtest::bgtest(model2)
#autocorrelation################################################################
e<-arima.sim(list(ar=0.99),1000) #using arima.sim to generate autocorrelated residuals
plot(e)
for (i in 1:1000) {
  data$y3[i]<-1+2*data$x[i]+e[i]
}
model3<-lm(y3~x,data)
plot(model3$residuals) #now looks like something may be up, there's a pattern here
acf(model3$residuals) #correlations between first residual and its lags are persistently large
lmtest::dwtest(model3) #can reject the null of no serial correlation, assuming AR(1) errors
lmtest::bgtest(model3,order=2) #can reject the null of no serial correlation, assuming AR(2) errors
#alternative ways to induce weird error terms###################################
#can more directly induce heteroskedasticity by making standard deviation of residuals depend on different values of x
sd<-ifelse(data$x>1,10,5)
for (i in 1:1000) {
  data$y4[i]<-1+2*data$x[i]+rnorm(1000,0,sd)[i]
}
plot(lm(y4~x,data)$residuals) #still hard to tell heteroskedasticity from plotting residuals
plot(lm(y4~x,data),which=3) #but again line isn't flat
lmtest::bptest(data$y4~data$x) #can reject null of homoskedasticity
#another function to generate autocorrelated series
u<-stats::filter(rnorm(1000),0.99,method="recursive")
plot(u)
for (i in 1:1000) {
  data$y5[i]<-1+2*data$x[i]+u[i]
}
acf(lm(y5~x,data)$residuals) #correlations between first residual and its lags are persistently large
lmtest::dwtest(lm(y5~x,data)) #can reject the null of no serial correlation with AR(1) residuals
lmtest::bgtest(lm(y5~x,data),order=2) #can reject the null of no serial correlation with AR(2) residuals