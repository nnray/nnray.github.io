mc1<-function(p){
  library(sandwich)
  set.seed(1)
  M=500
  N=1000
  data<-data.frame(
    x=arima.sim(list(ar=0.5),N)
  )
  results<-data.frame(
    b1_hat=rep(NA,M),
    se_OLS=rep(NA,M),
    se_NW=rep(NA,M),
    sd=rep(NA,M),
    confidence=rep(NA,M),
    bias=rep(NA,M),
    rho=rep(p,M)
  )
  for (m in 1:M) {
    e<-arima.sim(list(ar=p),N)
    for (i in 1:N) {
      data$y[i]<-1+2*data$x[i]+e[i]
    }
    results[m,1]<-summary(lm(y~x,data))$coefficients[2]
    results[m,2]<-summary(lm(y~x,data))$coefficients[4]
    results[m,3]<-sqrt(diag(NeweyWest(lm(y~x,data),lag=(N^(1/4)))))[2]
  }
  results[,4]<-sqrt(sum((results$b1_hat-mean(results$b1_hat))^2)/length(results$b1_hat))
  results[,5]<-results$sd/mean(results$se_OLS)
  results[,6]<-mean(results$b1_hat)-2
  return(results)
}
t<-mc1(-0.99)
u<-mc1(-0.75)
v<-mc1(-0.25)
w<-mc1(-0.5)
x<-mc1(0)
y<-mc1(0.25)
z<-mc1(0.5)
aa<-mc1(0.75)
bb<-mc1(0.99)
library(tidyverse)
mcdata1<-full_join(t,u) %>%
  full_join(.,v) %>%
  full_join(.,w) %>%
  full_join(.,x) %>%
  full_join(.,y) %>%
  full_join(.,z) %>%
  full_join(.,aa) %>%
  full_join(.,bb)
plot<-ggplot(mcdata1,aes(rho,se_OLS))+geom_point()
plot<-plot+geom_line(aes(rho,sd))
plot<-plot+labs(title="The effect of serial correlation on standard errors.",
                subtitle="500 simulated models each with 1000 observations.\nPoints represent the standard errors of the slope estimate from each model.\nThe line represents the standard deviation of the slope estimate for each value of AR(p).",
                x="Order of AR(p) disturbances",
                y="OLS standard errors")
plot2<-ggplot(mcdata1,aes(rho,se_NW))+geom_point()
plot2<-plot2+geom_line(aes(rho,sd))
plot2<-plot2+labs(title="The effect of serial correlation on Newey-West standard errors.",
                subtitle="500 simulated models each with 1000 observations.\nPoints represent the standard errors of the slope estimate from each model.\nThe line represents the standard deviation of the slope estimate for each value of AR(p).",
                x="Order of AR(p) disturbances",
                y="Newey-West standard errors")