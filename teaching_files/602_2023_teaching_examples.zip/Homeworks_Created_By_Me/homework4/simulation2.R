set.seed(1) 
library(lmtest)
M=100
N=1000
p=0.99
data<-data.frame(
  x=rnorm(N)
)
results<-data.frame(
  b1_hat=rep(NA,M),
  se=rep(NA,M),
  sd=rep(NA,M),
  confidence=rep(NA,M),
  bias=rep(NA,M)
)
for (m in 1:M) {
  e<-arima.sim(list(ar=p),N)
  for (i in 1:N) {
    data$y[i]<-1+2*data$x[i]+e[i]
  }
  results[m,1]<-summary(lm(y~x,data))$coefficients[2]
  results[m,2]<-summary(lm(y~x,data))$coefficients[4]
}
results[,3]<-sqrt(sum((results$b1_hat-mean(results$b1_hat))^2)/length(results$b1_hat))
results[,3]<-sd(results$b1_hat)
results[,4]<-results$sd/mean(results$se)
results[,5]<-mean(results$b1_hat)-2