X<-matrix(c(rep(1,4), #note the column of ones
            1,5,8,9), ncol=2)

Y<-matrix(c(3,4,7,10), ncol=1)

b_hat<-solve(t(X)%*%X) %*% t(X)%*%Y #OLS estimator

plot(X[,2], Y)
abline(b_hat[1], b_hat[2])

P<-X%*%solve(t(X)%*%X)%*%t(X) #projection matrix
P%*%Y #predicted values

M<-diag(4)-P #residual maker matrix
M%*%Y #residuals

Y-(Y-X%*%b_hat) #Y minus residuals = predicted values, or P times Y
Y-X%*%b_hat #Y minus Xb = residuals, or M times Y

#double-checking against canned functions
model<-lm(Y~X[,2])
model$coefficients
predict(model)
residuals(model)

sum((M%*%Y)^2) #sum of squared residuals (SSR)

candidate_values<-seq(0,2,0.001) #candidate values for b_hat we'll evaluate

SSR<-function(b0,b1){
  sum( (Y - X%*%matrix(c(b0,b1)))^2 )
}

#plotting SSR for candidate values of b1, holding b0 fixed at 1.4
plot(candidate_values,
     unlist(lapply(candidate_values,SSR,b0=1.4)))

#finding which index has smallest value (putting on scale of index, subtracting first number)
which.min(lapply(candidate_values,SSR,b0=1.4))*0.001-0.001

#plotting SSR for candidate values of b1, holding b1 fixed at 0.8
plot(candidate_values,
     unlist(lapply(candidate_values,SSR,b1=0.8)))

#finding which index has smallest value (putting on scale of index, subtracting first number)
which.min(lapply(candidate_values,SSR,b1=0.8))*0.001-0.001
