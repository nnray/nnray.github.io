library(tidyverse)

billboard
# each row is a song
# columns are: artist, track, date.entered, and then 76 columns for wk1 thru wk76
# values in each week column are the song's billboard rank that week


# let's restructure this into a song-week panel

# (Note that this will not be a proper panel, as the "weeks" are relative
#   to each song's release date. Ignore that for the sake of this exercise.)

# initialize an empty billboard_panel
billboard_panel = tibble(artist = character(), 
                         track = character(),
                         date.entered = date(),
                         week = double())

# for some reason, can't initialize a date column, so converting it separately
billboard_panel = billboard_panel |> 
  mutate(
    date.entered = as.Date(date.entered)
  )

# iterate through the rows in billboard, 
#  create 76 new rows for each row,
#  append on to the bottom of billboard_panel
for(i in 1:nrow(billboard)){
  # printing out indices, just to track progress
  if(i%%100==0){cat(i,'\t')}
  
  cur_artist = billboard$artist[i]
  cur_track = billboard$track[i]
  cur_date = billboard$date.entered[i]
  
  cur_panel = bind_cols(artist=cur_artist, 
                        track = cur_track, 
                        date.entered = cur_date,
                        week = 1:76)
  
  billboard_panel = billboard_panel |> bind_rows(cur_panel)
}

# inspect the resulting dataset
dim(billboard_panel) # 24092 rows, 4 cols


# initialize an empty "rank" column, which we will fill in
billboard_panel$rank = NA_real_

# now we have the identifying variables for our song-week panel
# let's copy in the rank values from the original dataset

# store mismatches
mismatch_inds = c()

for(i in 1:nrow(billboard_panel)){
  # printing out indices, just to track progress
  if(i%%1000==0){cat(i,'\t')}
  
  cur_artist = billboard_panel$artist[i]
  cur_track = billboard_panel$track[i]
  cur_date = billboard_panel$date.entered[i]
  cur_week = billboard_panel$week[i]
  
  billboard_row = which(billboard$artist==cur_artist & 
                          billboard$track==cur_track & 
                          billboard$date.entered==cur_date)
  
  # confirm that we've matched to a single row in billboard
  if(length(billboard_row)!=1){
    cat('\nrow match error: ', cur_artist, '\t', cur_track, '\t', cur_week,'\n')
    mismatch_inds = c(mismatch_inds, i)
    next # skip this row, inspect after we're done
    }
  
  billboard_col = paste0('wk',cur_week)
  # confirm that this column name exists in billboard
  if(!billboard_col %in% names(billboard)){
    cat('\ncolumn match error: ', billboard_col,'\n')
    next
  }
  
  # grab the rank value from the original data
  #  if you just index into billboard, it will return a tibble column, 
  #   rather than just the value, so unlist() to extract the value
  cur_rank = billboard[billboard_row, billboard_col] |> unlist()
  
  # copy it into the current row in the panel
  billboard_panel$rank[i] = cur_rank
}


# now let's do it the tidyverse way
billboard_pivoted = billboard |> 
  pivot_longer(
    cols = starts_with("wk"), 
    names_to = "week", 
    values_to = "rank"
  )

# rename the week variable to match the billboard_panel
billboard_pivoted = billboard_pivoted |>
  mutate(
    week = week |> str_remove('wk') |> as.numeric()
  )

# check dimensions
dim(billboard_pivoted) # 24092 rows, 5 cols (same num rows as the manual version)

# now let's merge these two together, manually

# for the sake of the exercise, I'm going to drop a couple rows in billboard_panel,
#  and duplicate a couple rows in billboard_pivoted, just to stress-test our functions

billboard_panel_messy = billboard_panel[-c(1234, 2345, 3456),]
billboard_pivoted_messy = billboard_pivoted |> add_row(billboard_pivoted[5555,], .before=5555)


# now let's go through and manually merge

mismatch_inds = c()

billboard_panel_messy$rank2 = NA_real_

# iterate over rows in billboard_panel
for(i in 1:nrow(billboard_panel_messy)){
  cur_artist = billboard_panel_messy$artist[i]
  cur_track = billboard_panel_messy$track[i]
  cur_date = billboard_panel_messy$date.entered[i]
  cur_week = billboard_panel_messy$week[i]
  
  # identify the matching row in billboard_pivoted_messy
  match_row = which(
    billboard_pivoted_messy$artist==cur_artist &
      billboard_pivoted_messy$track==cur_track &
      billboard_pivoted_messy$date.entered==cur_date &
      billboard_pivoted_messy$week==cur_week 
  )
  
  if(length(match_row)!=1){
    cat('\nrow match error: ', cur_artist, '\t', cur_track, '\t', cur_week,'\n')
    mismatch_inds = c(mismatch_inds, i)
    next
  }
  
  # grab the rank value from billboard_pivoted_messy
  cur_rank = billboard_pivoted_messy$rank[match_row]
  
  # store in the rank2 column
  billboard_panel_messy$rank2[i] = cur_rank

}

# check mismatch_inds
mismatch_inds
billboard_panel_messy[mismatch_inds,]

# inspect billboard_pivoted_messy
billboard_pivoted_messy |> 
  filter(artist=='De La Soul', track=='All Good?', week==7)

# decide how you want to handle this case

#  (in this instance, both rank values are the same, so decision is easy;
#   in practice, may have different values, and need to use your judgment...)


# now do this again, with left_join

# first, inspect num rows and cols
dim(billboard_panel_messy) # 24089 rows, 6 cols
dim(billboard_pivoted_messy) # 24093 rows, 5 cols

billboard_panel_messy_leftjoined = billboard_panel_messy |> 
  left_join(
    billboard_pivoted_messy |>
      # want to copy over the "rank" value, 
      #  rename it here to avoid naming conflicts
      rename(rank3=rank),
    by = c('artist','track','date.entered','week')
  )

dim(billboard_panel_messy_leftjoined) # 24090 rows, 7 cols
# so left_join just added a row to your dataset without telling you! 
# this is very bad!
