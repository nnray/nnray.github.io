#brief overview of the intuition behind the mechanics####
set.seed(1)
n=10
k=2
X<-matrix(c(rep(1,n),rnorm(n)),ncol=k) #n by k
Y<-matrix(rnorm(n),ncol=1) #n by 1
b<-solve(t(X)%*%X)%*%t(X)%*%Y #k by 1
P<-X%*%solve(t(X)%*%X)%*%t(X) #n by n
M<-diag(n)-P #n by n
e<-Y-X%*%b #Note: also can do M%*%Y
tr<-function(x){sum(diag(x))}

#plotting Y
plot(X[,2], Y,
     xlim=c(-1,2), ylim=c(-3,2))

#adding Y hat, or the fitted values
points(X[,2], P%*%Y, 
       col="red",pch=20)

#adding OLS coefficient vector (b)
abline(b[1],b[2],col="red")

#adding the residuals, M times Y
for(i in 1:n){
  segments(x0=X[i,2], y0=(P%*%Y)[i], #start line at fitted value
           x1=X[i,2], y1=(P%*%Y+M%*%Y)[i]) #end it M%*%Y units away
}

#variance-covariance matrix of b under homoskedasticity (and no autocorrelation)####
model<-lm(Y~X[,2])
vcov(model)
as.vector(((1/(n-k))*t(e)%*%e))*solve(t(X)%*%X)
#or
((1/(n-k))*tr(e%*%t(e)))*solve(t(X)%*%X)
#or
solve(t(X)%*%X)%*%t(X)%*%(as.vector(((1/(n-k))*t(e)%*%e))*diag(n))%*%X%*%solve(t(X)%*%X)

#variance-covariance matrix of b under heteroskedasticity (and no autocorrelation)####
D_hat=diag(e%*%t(e))*diag(n)
solve(t(X)%*%X)%*%t(X)%*%D_hat%*%X%*%solve(t(X)%*%X)
library(sandwich)
sandwich::vcovHC(model,"HC0")
library(estimatr)
lm_robust(Y~X[,2],se_type="HC0")
sqrt(diag(vcovHC(model,"HC0")))
library(lmtest)
coeftest(model,vcov.=vcovHC(model,"HC0"))

#some simulations with relatively extreme heteroskedasticity####
hetero<-function(n,m,sigma_X,sigma_e,b0,b1,HC_type){
  set.seed(1)
  library(sandwich)
  suppressWarnings(suppressPackageStartupMessages(library(tidyverse)))
  library(cowplot)
  data<-data.frame(X=rnorm(n,0,sigma_X))
  results<-data.frame(V_hat_b0=rep(NA,m),
                      V_hat_b1=rep(NA,m),
                      V_hat_robust_b0=rep(NA,m),
                      V_hat_robust_b1=rep(NA,m))
  for(j in 1:m){
    for(i in 1:n){
      data$Y[i]<-b0+b1*data$X[i]+rnorm(n,0,ifelse(data$X>0,sigma_e,1))[i]
      }
    model<-lm(Y~X,data)
    results[j,1]<-vcov(model)[1,1]
    results[j,2]<-vcov(model)[2,2]
    results[j,3]<-vcovHC(model,`HC_type`)[1,1]
    results[j,4]<-vcovHC(model,`HC_type`)[2,2]
  }
  return(
    plot_grid(
      ggplot(data)+
        geom_point(aes(x=X,y=Y))+
        labs(subtitle=bquote("Y~X, n="~.(n)~","~beta[0]~"="~.(b0)~","~beta[1]
                             ~"="~.(b1)~","~sigma["X"]~"="~.(sigma_X)~","
                             ~sigma["e"]~"="~"{"~"X"[i]<0~"="~1~","~"X"[i]>0
                             ~"="~.(sigma_e)~"}"),
             x=bquote("X"["Sim="~.(m)]),
             y=bquote("Y"["Sim="~.(m)]))+
        theme_bw(),
      ggplot(results)+
        geom_boxplot(aes(y=V_hat_b0,x=1))+
        geom_boxplot(aes(y=V_hat_b1,x=2))+
        geom_boxplot(aes(y=V_hat_robust_b0,x=3))+
        geom_boxplot(aes(y=V_hat_robust_b1,x=4))+
        labs(y="Sampling Variances",x="Estimator",
             subtitle=bquote(.(m)~"Simulations, "~"HC:"~.(HC_type)))+
        scale_x_continuous(breaks=1:4,
                           labels=expression(hat(italic(V))[hat(beta)[0]]^0,
                                             hat(italic(V))[hat(beta)[0]]^`HC`,
                                             hat(italic(V))[hat(beta)[1]]^0,
                                             hat(italic(V))[hat(beta)[1]]^`HC`))+
        theme_bw(),
      ncol=2)
    )
}

suppressWarnings(library(cowplot))
#varying number of observations (n)
plot_grid(
  hetero(n=100,100,1,5,0,1,"HC0"),
  hetero(n=500,100,1,5,0,1,"HC0"),
  hetero(n=1000,100,1,5,0,1,"HC0"),
  nrow=3
)

#varying sample variance of X (sigma_X)
plot_grid(
  hetero(500,100,sigma_X=0.1,5,0,1,"HC0"),
  hetero(500,100,sigma_X=1,5,0,1,"HC0"),
  hetero(500,100,sigma_X=2,5,0,1,"HC0"),
  nrow=3
)

#varying heteroskedasticity (conditional variance of residuals, sigma_e)
plot_grid(
  hetero(500,100,1,sigma_e=1,0,1,"HC0"),
  hetero(500,100,1,sigma_e=5,0,1,"HC0"),
  hetero(500,100,1,sigma_e=10,0,1,"HC0"),
  nrow=3
)

#Note that this is simply comparing variances, when we discuss inference then we would want to know if standard errors are "too small" in each of these circumstances
