library(here);library(tidyverse);library(readxl)
#vote shares####################################################################
votes<-read.csv(here("data","cmp","CMP.csv")) %>%
  rename(country=countryname,country_code=country,year=edate,votes=pervote,
         party=partyname,party_number=party,party_code=partyabbrev,family=parfam) %>%
  select(country,year,votes,party,party_number,family) %>%
  #coding according to "parfam" in CMP codebook
  mutate(year=as.numeric(gsub('../../','',year)),
         left_main=case_when(family==30 | family==40 ~ votes),
         right_main=case_when(family==50 | family==60 ~ votes),
         right_pop=case_when(family==70 ~ votes),
         left_pop=case_when(family==20 ~ votes)) %>%
  #averaging voteshare for a party if in more than one election in a year (rare)
  group_by(country,year,party) %>%
  mutate(left_main=mean(left_main,na.rm=T),
         right_main=mean(right_main,na.rm=T),
         right_pop=mean(right_pop,na.rm=T),
         left_pop=mean(left_pop,na.rm=T)) %>%
  distinct(left_main,right_main,left_pop,right_pop) %>%
  group_by(country,year) %>%
  summarize(left_main=sum(left_main,na.rm=T),
            right_main=sum(right_main,na.rm=T),
            left_pop=sum(left_pop,na.rm=T),
            right_pop=sum(right_pop,na.rm=T)) %>%
  mutate(competitiveness=-(abs(50-left_main)+abs(50-right_main)),
         competitiveness_lag=dplyr::lag(competitiveness),
         right_main_lag=dplyr::lag(right_main),
         left_main_lag=dplyr::lag(left_main))
#social spending################################################################
spending<-read.csv(here("data","spending","spending.csv")) %>%
  rename(country=Reference.area,year=TIME_PERIOD,value=OBS_VALUE,
         unit=Unit.of.measure,program=Programme.type) %>%
  select(country,year,program,value,unit) %>%
  group_by(country,year,unit) %>%
  summarize(value=sum(value,na.rm=T)) %>%
  pivot_wider(id_cols=1:2,id_expand=T,names_from="unit",values_from="value") %>%
  rename(spending_dollars=`US dollars per person, PPP converted`,
         spending_percent=`Percentage of GDP`) %>%
  group_by(country) %>%
  mutate(log_spending_dollars=log(spending_dollars))
spending2<-read.csv(here("data","spending","spending.csv")) %>%
  rename(country=Reference.area,year=TIME_PERIOD,value=OBS_VALUE,
         unit=Unit.of.measure,program=Programme.type) %>%
  select(country,year,program,value,unit) %>%
  filter(program=="Active labour market programmes" | 
           program=="PES and Administration" |
           program=="Training" | program=="Job Rotation and Job Sharing" | 
           program=="Employment Incentives" | 
           program=="Supported Employment and Rehabilitation" |
           program=="Direct Job Creation" | program=="Start" |
           program=="Unemployment") %>%
  group_by(country,year,unit) %>%
  summarize(value=sum(value,na.rm=T)) %>%
  pivot_wider(id_cols=1:2,id_expand=T,names_from="unit",values_from="value") %>%
  rename(spending_dollars2=`US dollars per person, PPP converted`,
         spending_percent2=`Percentage of GDP`) %>%
  group_by(country) %>%
  mutate(log_spending_dollars2=log(spending_dollars2))
spending_joined<-full_join(spending,spending2)
#election#######################################################################
elections<-read.csv(here("data","elections","es_data-v4_1.csv")) %>%
  mutate(elec_id=str_sub(elec_id,end=2),
         enep=ifelse(enep==-99,NA,enep),
         year=as.numeric(str_sub(date,start=-4))) %>%
  filter(str_detect(elec_id,'L-'),
         regime<3) %>%
  select(country,year,enep,legislative_type,regime,tier1_avemag)
elections["country"][elections["country"]=="United States of America"]<-"United States"
#imports########################################################################
imports<-read.csv(here("data","trade","trade.csv")) %>%
  filter(TRANSFORMATION=="GY" | TRANSFORMATION=="N") %>%
  rename(country=Reference.area,year=TIME_PERIOD,value=OBS_VALUE,
         unit=Unit.of.measure) %>%
  select(country,year,value,unit) %>%
  group_by(country,year,unit) %>%
  summarize(value=sum(value,na.rm=T)) %>%
  pivot_wider(id_cols=1:2,id_expand=T,names_from="unit",values_from="value") %>%
  rename(imports_dollars=`US dollars, exchange rate converted`,
         imports_percent=`Percentage change`) %>%
  group_by(country) %>%
  mutate(log_imports_dollars=log(imports_dollars))
imports_china<-read.csv(here("data","trade","BTDIXE_I4_03042024225229167.csv")) %>%
  select(Reporting.country,Time,Value) %>%
  rename(country=Reporting.country,year=Time,imports_china=Value) %>%
  group_by(country) %>%
  mutate(log_imports_china=log(imports_china))
imports_joined<-full_join(imports,imports_china)
#joining into data##############################################################
data<-left_join(spending_joined,imports_joined) %>%
  left_join(.,elections) %>%
  left_join(.,votes) %>%
  arrange(country,year)
#Greece has three extra years and Ireland one (multiple elections)
data<-mutate(data,
             enep=ifelse(country=="Greece" & year==1989,mean(enep),enep),
             enep=ifelse(country=="Greece" & year==2012,mean(enep),enep),
             enep=ifelse(country=="Greece" & year==2015,mean(enep),enep),
             enep=ifelse(country=="Ireland" & year==1982,mean(enep),enep),
             legislative_type=ifelse(country=="Greece" & year==1989,
                                     mean(legislative_type),legislative_type),
             legislative_type=ifelse(country=="Greece" & year==2012,
                                     mean(legislative_type),legislative_type),
             legislative_type=ifelse(country=="Greece" & year==2015,
                                     mean(legislative_type),legislative_type)) %>%
  distinct()
#averaging over yearly data by election#########################################
data<-data %>%
  mutate(election_id=ifelse(is.na(competitiveness)==FALSE,row_number(),NA),
         year=ifelse(is.na(election_id),0,year)) %>%
  fill(enep,legislative_type,regime,tier1_avemag,left_main,right_main,left_pop,
       right_pop,competitiveness,competitiveness_lag,election_id,right_main_lag,
       left_main_lag,.direction="down") %>%
  group_by(country,election_id) %>%
  summarize(year=sum(year),
            spending_percent=mean(spending_percent,na.rm=T),
            spending_dollars=mean(spending_dollars,na.rm=T),
            log_spending_dollars=mean(log_spending_dollars,na.rm=T),
            spending_percent2=mean(spending_percent2,na.rm=T),
            spending_dollars2=mean(spending_dollars2,na.rm=T),
            log_spending_dollars2=mean(log_spending_dollars2,na.rm=T),
            imports_dollars=mean(imports_dollars,na.rm=T),
            log_imports_dollars=mean(log_imports_dollars,na.rm=T),
            imports_percent=mean(imports_percent,na.rm=T),
            imports_china=mean(imports_china,na.rm=T),
            log_imports_china=mean(log_imports_china,na.rm=T),
            enep=mean(enep),
            legislative_type=mean(legislative_type),
            regime=mean(regime),
            tier1_avemag=mean(tier1_avemag),
            left_main=mean(left_main),
            left_main_lag=mean(left_main_lag),
            right_main=mean(right_main),
            right_main_lag=mean(right_main_lag),
            left_pop=mean(left_pop),
            right_pop=mean(right_pop),
            competitiveness=mean(competitiveness),
            competitiveness_lag=mean(competitiveness_lag),
            election_id=mean(election_id)) %>%
  mutate(spending_percent=ifelse(spending_percent==0,NA,spending_percent)) %>%
  drop_na(spending_percent,election_id) %>%
  group_by(country) %>%
  mutate(spending_percent_lag=dplyr::lag(spending_percent),
         spending_percent2_lag=dplyr::lag(spending_percent2),
         spending_percent_diff=spending_percent-spending_percent_lag,
         spending_percent2_diff=spending_percent2-spending_percent2_lag,
         log_spending_dollars_lag=dplyr::lag(log_spending_dollars),
         log_spending_dollars_diff=log_spending_dollars-log_spending_dollars_lag,
         log_spending_dollars2_lag=dplyr::lag(log_spending_dollars2),
         log_spending_dollars2_diff=log_spending_dollars2-log_spending_dollars2_lag,
         log_imports_china_lag=dplyr::lag(log_imports_china),
         log_imports_dollars_lag=dplyr::lag(log_imports_dollars),
         imports_percent_lag=dplyr::lag(imports_percent)) %>%
  #new election_id
  arrange(country,year) %>%
  group_by(country) %>%
  mutate(election_id=row_number())
data<-data %>%
  mutate(log_spending_dollars2=ifelse(is.infinite(log_spending_dollars2),NA,
                                      log_spending_dollars2),
         log_spending_dollars2_diff=ifelse(is.infinite(log_spending_dollars2_diff),NA,
                                           log_spending_dollars2_diff),
         log_imports_china_lag=ifelse(is.nan(log_imports_china_lag),NA,log_imports_china_lag),
         log_spending_dollars2_lag=ifelse(is.infinite(log_spending_dollars2_lag),NA,
                                      log_spending_dollars2))
data<-mutate(data,right_main_lag_abs=abs(50-right_main_lag),
             left_main_lag_abs=abs(50-left_main_lag))
data<-mutate(data,crisis=ifelse(year>2007,1,0))
# write.csv(data,file=here("data","data.csv"),row.names = F)
#analysis#######################################################################
library(plm)
model1<-plm(spending_percent~spending_percent_lag+right_main_lag_abs+
              imports_percent,
            data,effect="twoways",index=c("country","year"))
model1_se<-sqrt(diag(plm::vcovDC(model1)))
model2<-plm(spending_percent~spending_percent_lag+right_main_lag_abs+
              imports_percent+enep,
            data,effect="twoways",index=c("country","year"))
model2_se<-sqrt(diag(plm::vcovDC(model2)))
model3<-plm(spending_percent~spending_percent_lag+right_main_lag_abs+
              imports_percent+tier1_avemag,
            data,effect="twoways",index=c("country","year"))
model3_se<-sqrt(diag(plm::vcovDC(model3)))
library(stargazer)
table<-stargazer(model2,model3,
          se=list(model2_se,model3_se),header=F,
          covariate.labels=c("Spending Lag",
                             "$|$50-Centrist Right$|$",
                             "\\%$\\Delta$ Imports",
                             "\\# Parties",
                             "Avg. Magnitude",
                              "\\%$\\Delta$ Imports"),
          dep.var.labels=c("Spending"))
##plots#########################################################################
#predicted (just for intuition)
pred1<-lm(spending_percent~abs(50-right_main_lag),data)
newdata<-data.frame(right_main_lag=seq(0,100,by=1))
yhat<-predict(pred1,newdata=newdata,interval="confidence")
plot(spending_percent~right_main_lag,data=data,
     xlab="|V-Right Main|",ylab="Social Spending",xlim=c(0,100))
lines(y=yhat[,"fit"],x=newdata$right_main_lag, lwd=2)
lines(y=yhat[,"lwr"],x=newdata$right_main_lag, col="blue", lty="dotted", lwd=2)
lines(y=yhat[,"upr"],x=newdata$right_main_lag, col="blue", lty="dotted", lwd=2)
#descriptive
library(panelr)
plot1<-data %>%
  panelr::panel_data(.,id=country,wave=year) %>%
  line_plot(.,right_main,overlay=F,line.size=0.5)+
  geom_line(aes(x=year,y=spending_percent))+
  geom_hline(yintercept=50,linetype="dashed")+
  labs(y="Main Right Vote Share",
       x="Year")
#theory#########################################################################
d_r_tft<-function(p,psi){(psi-p*psi)/(p*psi)}
d_r_gt<-function(p,psi,c){(psi-p*psi)/(psi-p*(psi-c))}
d_l_tft<-function(p,psi){(psi-(1-p)*psi)/((1-p)*psi)}
d_l_gt<-function(p,psi,c){(psi-(1-p)*psi)/(psi-(1-p)*(psi-c))}
theory<-data.frame(d_r_tft=rep(NA,101),
                   d_l_tft=rep(NA,101),
                   d_r_gt=rep(NA,101),
                   d_l_gt=rep(NA,101),
                   d_tft_sum=rep(NA,101),
                   d_gt_sum=rep(NA,101),
                   p=seq(from=0,to=1,by=0.01))
theory[,1]<-unlist(lapply(seq(from=0,to=1,by=0.01),d_r_tft,psi=5))
theory[,2]<-unlist(lapply(seq(from=0,to=1,by=0.01),d_l_tft,psi=5))
theory[,3]<-unlist(lapply(seq(from=0,to=1,by=0.01),d_r_gt,psi=5,c=2))
theory[,4]<-unlist(lapply(seq(from=0,to=1,by=0.01),d_l_gt,psi=5,c=2))
plot3<-ggplot(theory,aes(x=p,y=d_r_gt))+geom_point(colour="red")+
  geom_point(aes(x=p,y=d_l_gt),colour="blue")+
  labs(x="Probability of Right Winning (p)",
       y=expression(paste("Required Level of Patience ( ",delta,"*)")))+
  lims(y=c(0,1))
theory[,5]<-abs(theory[,1]-theory[,2])
theory[,6]<-abs(theory[,3]-theory[,4])
plot4<-ggplot(theory,aes(x=p,y=d_gt_sum))+geom_point()+
  labs(x="Probability of Right Winning (p)",
       y=expression(paste("Required Patience (| ",
                          delta[R],"*-",delta[L],"*|)")))+
  lims(y=c(0,1))
x<-function(p,psi,c){
  -(((psi-p*psi)/(psi-p*(psi-c)))-((psi-(1-p)*psi)/(psi-(1-p)*(psi-c))))
}
library(gridExtra)
# grid.arrange(plot3,plot4,
#              ncol=2)