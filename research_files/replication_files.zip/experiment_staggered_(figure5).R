# defining the experiment ######################################################

simulation <- function(
    
  units, periods, # N and T
  y_autocorrelation, # autocorrelation in the outcome
  treatment_effect, # homogeneous effect
  treatment_period, # when true short-run effect occurs
  sims, return_data, # number of simulations and option to return the data instead
  burn_periods, # number of time points to burn
  error_correlation,
  period_1, period_2 # the two treatment periods
  
){
  
  # required libraries
  library(MASS); library(tidyverse); library(fixest); library(did);
  library(foreach); library(doRNG); library(doParallel)
  
  set.seed(1)
  
  data <- data.frame(
    n = rep(1:units, each = (burn_periods + periods)),
    t = rep(1:(burn_periods + periods), units),
    y = NA
  )
  
  # half of the units are randomly selected to receive treatment
  treated_units <- sample(units, 0.5 * units)
  data <- mutate(data, treat = ifelse(n %in% treated_units, 1, 0))
  
  # of these, two random subgroups receive treatment
  treated_units_period_1 <- sample(treated_units, 0.5 * length(treated_units))
  treated_units_period_2 <- treated_units[!(treated_units %in% treated_units_period_1)]
  
  # including a variable for when the unit gets treated
  data <- mutate(data,
                 treatment_period = case_when(n %in% treated_units_period_1 ~ 1,
                                              n %in% treated_units_period_2 ~ 2),
                 treatment_period = ifelse(is.na(treatment_period), 0, treatment_period))
  
  # including a variable that is the effect for each treated unit
  data <- mutate(data,
                 treatment_effect = case_when(
                   treat == 1 & t >= (burn_periods + period_1) & treatment_period == 1 ~ treatment_effect,
                   treat == 1 & t >= (burn_periods + period_2) & treatment_period == 2 ~ treatment_effect,
                 ),
                 treatment_effect = ifelse(is.na(treatment_effect), 0, treatment_effect))
  
  # creating the "post" variable that will be used in the DiD regression (using `fixest`)
  data <- mutate(data, d = ifelse(treat == 1 & treatment_effect > 0, 1, 0))
  
  # empty data.frame to store results
  results <- data.frame(
    
    # number of units
    units = NA,
    
    # estimates of the "post" variable d
    d_hat_iid = NA, d_hat_clustered = NA, d_hat_ldv = NA, d_hat_adl11 = NA,
    
    # estimates of the standard deviation of the "post" variable d
    se_hat_iid = NA, se_hat_clustered = NA, se_hat_ldv = NA, se_hat_adl11 = NA
    
  )
  
  # number of cores to use for parallelization and registering them
  cl <- makeCluster(detectCores())
  registerDoParallel(cl)
  
  # parallelized simulation
  results <- foreach(
    s = 1:sims, .combine = rbind, .packages = c("MASS", "tidyverse", "fixest")
  ) %dorng% {
    
    # generating error terms s.t. the unit roots have parallel trends
    sigma = diag(units) + error_correlation - (diag(units) * error_correlation)
    error_terms <- mvrnorm(
      (burn_periods + periods),
      rep(0, units),
      sigma
    )
    
    for(i in 1:units){
      
      data[, "y"][data[ , "n"] == i][1] <- error_terms[1, i]
      
      for(j in 2:(burn_periods + periods)){
        
        data[, "y"][data[ , "n"] == i][j] <- y_autocorrelation *
          data[, "y"][data[ , "n"] == i][j - 1] + error_terms[j, i] +
          data[, "treatment_effect"][data[ , "n"] == i][j]
        
      }
      
    }
    
    data <- filter(data, t > burn_periods)
    
    results[s, "units"] <- units
    
    # calculating lags of y and d for ldv and adl models
    lag_data <- data %>% group_by(n) %>% mutate(y_lag = lag(y), d_lag = lag(d))
    
    # static model with standard errors estimated iid, TWFE
    iid <- feols(y ~ d | n + t, data, vcov = "iid")
    results[s, "d_hat_iid"] <- iid[["coefficients"]][["d"]]
    results[s, "se_hat_iid"] <- iid[["se"]][["d"]]
    
    # static model with standard errors clustered on unit, TWFE
    clustered <- feols(y ~ d | n + t, data, vcov = cluster ~ n)
    results[s, "d_hat_clustered"] <- clustered[["coefficients"]][["d"]]
    results[s, "se_hat_clustered"] <- summary(clustered)[["se"]][["d"]]
    
    # ldv model with standard errors estimated iid, TWFE
    ldv <- feols(y ~ y_lag + d | n + t, lag_data, vcov = "iid")
    results[s, "d_hat_ldv"] <- ldv[["coefficients"]][["d"]]
    results[s, "se_hat_ldv"] <- ldv[["se"]][["d"]]
    
    # adl(1,1) model with standard errors estimated iid, TWFE
    adl11 <- feols(y ~ y_lag + d + d_lag | n + t, lag_data, vcov = "iid")
    results[s, "d_hat_adl11"] <- adl11[["coefficients"]][["d"]]
    results[s, "se_hat_adl11"] <- adl11[["se"]][["d"]]
    
    results[s, ]
    
  }
  
  # close back-end
  stopCluster(cl)
  
  if(return_data == T){return(data)} else{return(results)}
  
}

# conducting the experiments ###################################################

# # simulation 5 (used for Figure 5)
system.time(output <- simulation(
  units = 50,
  periods = 10,
  y_autocorrelation = 1,
  treatment_effect = 1,
  sims = 1000,
  return_data = F,
  burn_periods = 100,
  error_correlation = 0.9,
  period_1 = 3,
  period_2 = 6
))

# extra simulation to see if results hold with stationary data
# system.time(output <- simulation(
#   units = 50,
#   periods = 10,
#   y_autocorrelation = 0.5,
#   treatment_effect = 1,
#   sims = 1000,
#   return_data = F,
#   burn_periods = 100,
#   error_correlation = 0.9,
#   period_1 = 3,
#   period_2 = 6
# ))

# calculating and plotting results #############################################

# plotting estimates of the "post" variable d
estimates <- ggplot(output) +
  geom_point(aes(x = 0, y = d_hat_iid)) +
  geom_point(aes(x = 1, y = d_hat_clustered)) +
  geom_point(aes(x = 2, y = d_hat_ldv)) +
  geom_point(aes(x = 3, y = d_hat_adl11)) +
  geom_hline(yintercept = 1, linetype = "dashed") +
  scale_x_continuous(breaks = c(0, 1, 2, 3),
                     labels = c(expression(paste("Static, ", italic(iid),)),
                                "Static, clustered",
                                "LDV",
                                "ADiDL(1,1)       ")) +
  labs(title = "Estimated Treatment Effects", x = "Estimators", y = "Effect") +
  theme_bw()

# calculating the standard deviation of d_hat
output <- mutate(output,
                 sd_clustered = sd(d_hat_clustered),
                 sd_iid = sd(d_hat_iid),
                 sd_ldv = sd(d_hat_ldv),
                 sd_adl11 = sd(d_hat_adl11))

# plotting estimated standard deviations of d_hat
ses <- ggplot(output) +
  geom_point(aes(x = 0, y = se_hat_iid)) +
  geom_point(aes(x = 0, y = sd_iid, colour = "SD of Effect Estimates")) +
  geom_point(aes(x = 1, y = se_hat_clustered)) +
  geom_point(aes(x = 1, y = sd_clustered, colour = "SD of Effect Estimates")) +
  geom_point(aes(x = 2, y = se_hat_ldv)) +
  geom_point(aes(x = 2, y = sd_ldv, colour = "SD of Effect Estimates")) +
  geom_point(aes(x = 3, y = se_hat_adl11)) +
  geom_point(aes(x = 3, y = sd_adl11, colour = "SD of Effect Estimates")) +
  scale_x_continuous(breaks = c(0, 1, 2, 3),
                     labels = c(expression(paste("Static, ", italic(iid),)),
                                "Static, clustered",
                                "LDV",
                                "ADiDL(1,1)       ")) +
  labs(title = "Estimated Standard Deviations", colour = "Legend", x = "Estimators", y = "SE") +
  theme_bw() +
  theme(legend.position = "bottom")

library(cowplot); library(here)

# after running simulation 5
pdf(here("figures", "Staggered_Unit_Root.pdf"), width = 10, height = 6)

plot_grid(
  estimates, ses,
  nrow = 1
)

dev.off()

# after running extra simulation on stationary data
# pdf(here("figures", "Staggered_Stationary.pdf"), width = 15, height = 8.75)
# 
# plot_grid(
#   estimates, ses,
#   nrow = 1
# )
# 
# dev.off()

# plotting average outcomes from one representative dataset ####################

units = 100
periods = 10
burn_periods = 100
y_autocorrelation = 1
treatment_effect = 1
error_correlation = 0.9
period_1 = 3
period_2 = 6

library(tidyverse)

set.seed(1)

data <- data.frame(
  n = rep(1:units, each = (burn_periods + periods)),
  t = rep(1:(burn_periods + periods), units),
  y = NA
)

# half of the units are randomly selected to receive treatment
treated_units <- sample(units, 0.5 * units)
data <- mutate(data, treat = ifelse(n %in% treated_units, 1, 0))

# of these, two random subgroups receive treatment
treated_units_period_1 <- sample(treated_units, 0.5 * length(treated_units))
treated_units_period_2 <- treated_units[!(treated_units %in% treated_units_period_1)]

# including a variable for when the unit gets treated
data <- mutate(data,
               treatment_period = case_when(n %in% treated_units_period_1 ~ 1,
                                            n %in% treated_units_period_2 ~ 2),
               treatment_period = ifelse(is.na(treatment_period), 0, treatment_period))

# including a variable that is the effect for each treated unit
data <- mutate(data,
               treatment_effect = case_when(
                 treat == 1 & t >= (burn_periods + period_1) & treatment_period == 1 ~ treatment_effect,
                 treat == 1 & t >= (burn_periods + period_2) & treatment_period == 2 ~ treatment_effect,
               ),
               treatment_effect = ifelse(is.na(treatment_effect), 0, treatment_effect))

# creating the "post" variable that will be used in the DiD regression (using `fixest`)
data <- mutate(data, d = ifelse(treat == 1 & treatment_effect > 0, 1, 0))

library(MASS)

sigma = diag(units) + error_correlation - (diag(units) * error_correlation)

error_terms <- mvrnorm(
  (burn_periods + periods),
  rep(0, units),
  sigma
)

for(i in 1:units){
  
  data[, "y"][data[ , "n"] == i][1] <- error_terms[1, i]
  
  # making y autocorrelated within units, plus treatment (non iid within units)
  for(j in 2:(burn_periods + periods)){
    
    data[, "y"][data[ , "n"] == i][j] <- y_autocorrelation *
      data[, "y"][data[ , "n"] == i][j - 1] + error_terms[j, i] +
      data[, "treatment_effect"][data[ , "n"] == i][j]
    
  }
  
}

# burning the burn_in periods
data <- filter(data, t > burn_periods)

# average outcome within treated and control groups
averages <- data %>%
  group_by(t, treat, treatment_period) %>%
  summarize(average_y = mean(y))

library(here)

pdf(here("figures", "Staggered_Data.pdf"), width = 4, height = 4)

ggplot() +
  geom_line(aes(x = t, y = average_y, colour = "Time 1"),
            data = filter(averages, treat == 1, treatment_period == 1)) +
  geom_point(aes(x = t, y = average_y, colour = "Time 1"),
             data = filter(averages, treat == 1, treatment_period == 1)) +
  geom_line(aes(x = t, y = average_y, colour = "Time 2"),
            data = filter(averages, treat == 1, treatment_period == 2)) +
  geom_point(aes(x = t, y = average_y, colour = "Time 2"),
             data = filter(averages, treat == 1, treatment_period == 2)) +
  geom_line(aes(x = t, y = average_y, colour = "Control"),
            data = filter(averages, treat == 0)) +
  geom_point(aes(x = t, y = average_y, colour = "Control"),
             data = filter(averages, treat == 0)) +
  scale_x_continuous(breaks = c(101, 102, 103, 104, 105, 106, 107, 108, 109, 110),
                     labels = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)) +
  geom_vline(xintercept = (burn_periods + period_1), linetype = "dashed", color = "green") +
  geom_vline(xintercept = (burn_periods + period_2), linetype = "dashed", color = "blue") +
  labs(x = "Time (After Burn-in Periods)", y = "Average Outcome",
       colour = "Legend", title = "Average Outcomes by Group") +
  theme_bw() +
  theme(legend.position = "bottom")

dev.off()
