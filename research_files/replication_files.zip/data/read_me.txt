Milner replication data from https://doi.org/10.7910/DVN/ZTEIKG.

"oecd.csv" is from the OECD Data Explorer website and specifically the OECD Social Expenditure Database (https://www.oecd.org/social/expenditure.htm).

"IDD_20012024193837170.csv" is from the OECD.Stat website and, specifically, the Income Distribution Database (https://stats.oecd.org/Index.aspx?DataSetCode=IDD#).

"es_data-v41.zip" is from http://mattgolder.com/elections.

"CMP.zip" is from https://manifesto-project.wzb.eu/.

populism from https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/WMGTNS.

dart https://dart.lisdatacenter.org/dart

BTDIXE_I4_03042024225229167 from "https://stats.oecd.org/Index.aspx?DataSetCode=BTDIXE_I4#"