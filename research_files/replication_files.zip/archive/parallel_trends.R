# parallel trends: "in the absence of treatment, the average outcomes for treated and comparison groups would have followed parallel paths over time" (Callaway and Sant'Anna 2020, p. 200)

# assessing parallel trends from experiment 1 ##################################

# generating a one-shot dataset like the ones in the experiment:

units = 100
periods = 20
burn_periods = 100
y_autocorrelation = 1
treatment_effect = 0
treatment_period = 10

library(tidyverse)

set.seed(1)

data <- data.frame(
  n = rep(1:units, each = (burn_periods + periods)),
  t = rep(1:(burn_periods + periods), units),
  y = NA
)

# half of the units are randomly selected to receive treatment
treated_units <- sample(units, 0.5 * units)
data <- mutate(data, treat = ifelse(n %in% treated_units, 1, 0))

# creating a variable for the true treatment for easier simulating
data <- mutate(data, treatment_effect = ifelse(treat == 1 & t == (burn_periods + treatment_period), treatment_effect, 0))

# creating the "post" variable that will be used in the DiD regression (using `fixest`)
data <- mutate(data, d = ifelse(treat == 1 & t >= (burn_periods + treatment_period), 1, 0))

# creating the "first treat" variable used in `did` package estimation
data <- mutate(data, first.treat = ifelse(treat == 1, (burn_periods + treatment_period), 0))

for(i in 1:units){
  
  # within each unit i, making the first observation a random draw (iid across units)
  data[, "y"][data[ , "n"] == i][1] <- rnorm(1)
  
  # making y autocorrelated within units, plus treatment (non iid within units)
  for(j in 2:(burn_periods + periods)){
    
    data[, "y"][data[ , "n"] == i][j] <- y_autocorrelation *
      data[, "y"][data[ , "n"] == i][j - 1] + rnorm(1) +
      data[, "treatment_effect"][data[ , "n"] == i][j]
    
  }
  
}

# burning the burn_in periods
data <- filter(data, t > burn_periods)

# average outcome within treated and control groups
averages <- data %>%
  group_by(t, treat) %>%
  summarize(average_y = mean(y))

# assessing if they're parallel (since treatment effect was 0)
ggplot() +
  geom_line(aes(x = t, y = average_y, colour = "Treated"),
            data = filter(averages, treat == 1)) +
  geom_line(aes(x = t, y = average_y, colour = "Control"),
            data = filter(averages, treat == 0)) +
  labs(x = "Time (After Burn-in Periods)", y = "Average Outcome",
       colour = "Legend") +
  theme_bw()

# alternative way to ensure parallel trends ####################################

units = 100
periods = 20
burn_periods = 100
y_autocorrelation = 1
treatment_effect = 0
treatment_period = 10
error_correlation = 0.9 # make higher (but < 1) to better approximate parallel trends

library(tidyverse)

set.seed(1)

data <- data.frame(
  n = rep(1:units, each = (burn_periods + periods)),
  t = rep(1:(burn_periods + periods), units),
  y = NA
)

# half of the units are randomly selected to receive treatment
treated_units <- sample(units, 0.5 * units)
data <- mutate(data, treat = ifelse(n %in% treated_units, 1, 0))

# creating a variable for the true treatment for easier simulating
data <- mutate(data, treatment_effect = ifelse(treat == 1 & t == (burn_periods + treatment_period), treatment_effect, 0))

# creating the "post" variable that will be used in the DiD regression (using `fixest`)
data <- mutate(data, d = ifelse(treat == 1 & t >= (burn_periods + treatment_period), 1, 0))

# within each unit i, making the first observation the same random draw
data[, "y"][data[, "t"] == 1] <- rnorm(1)

library(MASS)

sigma = diag(units) + error_correlation - (diag(units) * error_correlation)

error_terms <- mvrnorm(
  (burn_periods + periods),
  rep(0, units),
  sigma
)

for(i in 1:units){
  
  data[, "y"][data[ , "n"] == i][1] <- error_terms[1, i]
  
  # making y autocorrelated within units, plus treatment (non iid within units)
  for(j in 2:(burn_periods + periods)){
    
    data[, "y"][data[ , "n"] == i][j] <- y_autocorrelation *
      data[, "y"][data[ , "n"] == i][j - 1] + error_terms[j, i] +
      data[, "treatment_effect"][data[ , "n"] == i][j]
    
  }
  
}

# burning the burn_in periods
data <- filter(data, t > burn_periods)

# average outcome within treated and control groups
averages <- data %>%
  group_by(t, treat) %>%
  summarize(average_y = mean(y))

# assessing if they're parallel (since treatment effect was 0)
ggplot() +
  geom_line(aes(x = t, y = average_y, colour = "Treated"),
            data = filter(averages, treat == 1)) +
  geom_line(aes(x = t, y = average_y, colour = "Control"),
            data = filter(averages, treat == 0)) +
  labs(x = "Time (After Burn-in Periods)", y = "Average Outcome",
       colour = "Legend") +
  theme_bw()

ggplot() +
  geom_line(aes(x = t, y = y), data = filter(data, n == 1)) +
  geom_line(aes(x = t, y = y), data = filter(data, n == 2)) +
  geom_line(aes(x = t, y = y), data = filter(data, n == 3)) +
  geom_line(aes(x = t, y = y), data = filter(data, n == 4)) +
  geom_line(aes(x = t, y = y), data = filter(data, n == 5))
