library(here);library(haven);library(tidyverse)
#Milner data####################################################################
data<-read_dta(here("stata_replication","milner_2021",
                    "imputed_econdata_voteshare_merged.dta")) %>%
  as.data.frame()
#social spending data###########################################################
data<-read.csv(here("stata_replication","oecd.csv")) %>%
  select(Reference.area,Expenditure.source,Programme.type,TIME_PERIOD,OBS_VALUE) %>%
  rename(cname=Reference.area,year=TIME_PERIOD) %>%
  group_by(cname,year) %>%
  summarize(spending=sum(OBS_VALUE)) %>%
  right_join(.,data,by=c("cname","year"))
# write_dta(data,here("data","milner","data.dta"))