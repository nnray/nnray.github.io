#homoskedasticity and no autocorrelation########################################
library(lmtest);library(tidyverse)
set.seed(1)
data<-data.frame(
  x=rnorm(1000)
)
for (i in 1:1000) {
  data$y[i]<-1+2*data$x[i]+rnorm(1000)[i]
}
model<-lm(y~x,data)
plot(model$residuals) #no obvious pattern
plot(model,which=3) #no obvious deviations from flat line
lmtest::bptest(model) #can't reject null of homoskedasticity
acf(model$residuals) #lags of the residuals may be correlated
lmtest::dwtest(model) #can't reject null of no autocorrelation assuming AR(1) errors
lmtest::bgtest(model,order=2) #can't reject null of no autocorrelation assuming AR(2) errors
#heteroskedasticity#############################################################
for (i in 1:1000) {
  data$y2[i]<-1+2*data$x[i]+rnorm(1000)[i]
}
data<-mutate(data,y2=ifelse(x>1,rnorm(1000),y2)) #inducing heteroskedasticity
model2<-lm(y2~x,data)
plot(model2$residuals)
plot(model2,which=3) #line isn't flat
lmtest::bptest(model2) #reject the null of homoskedasticity
#autocorrelation################################################################
for (i in 1:1000) {
  data$y3[i]<-1+2*data$x[i]+arima.sim(list(ar=0.9),1000)[i]
}
plot(arima.sim(list(ar=0.9),1000)) #showing a series created by arima.sim()
model3<-lm(y3~x,data)
plot(model3$residuals)
acf(model3$residuals) #lags of the residuals seem correlated
lmtest::dwtest(model3) #but can't reject null
lmtest::bgtest(model3,order=2)
#alternative ways to induce weird error terms###################################
#can more directly induce heteroskedasticity by making standard deviation of residuals depend on different values of x
sd<-ifelse(data$x>1,10,5)
for (i in 1:1000) {
  data$y4[i]<-1+2*data$x[i]+rnorm(1000,0,sd)[i]
}
plot(lm(y4~x,data),which=3)
lmtest::bptest(data$y4~data$x)
#another function to generate autocorrelated series
for (i in 1:1000) {
  data$y5[i]<-1+2*data$x[i]+stats::filter(rnorm(1000),0.9,method="recursive")[i]
}
plot(stats::filter(rnorm(1000),0.9,method="recursive"))
acf(lm(y5~x,data)$residuals) #some significant correlations between lags
lmtest::dwtest(lm(y5~x,data)) #still can't reject null
lmtest::bgtest(lm(y5~x,data),order=1)